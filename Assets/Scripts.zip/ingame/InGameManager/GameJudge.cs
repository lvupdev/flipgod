using UnityEngine;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ingame{
    public class GameJudge {

        public GameJudge() {
        }

        public float timeLimit { get; set; }

        public int bottleLimit { get; set; }

        public int bottleHit { get; set; }


        public int result() {
            // TODO implement here
            return 0;
        }

    }
}