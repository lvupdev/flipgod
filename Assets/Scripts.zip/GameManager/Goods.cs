using UnityEngine;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace gamemgr{
    public class Goods {

        public Goods() {
        }

        public int id;

        public int price { get; set; }


        public void operate() {
            // TODO implement here
        }

    }
}