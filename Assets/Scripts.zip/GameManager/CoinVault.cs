using UnityEngine;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace gamemgr{
    public class CoinVault {

        public CoinVault() {
        }

        public int allCoin { get; set; }

    }
}